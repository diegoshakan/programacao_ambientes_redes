from socket import *
 
meuHost = ''
 
minhaPort = 50007
 
# Cria um objeto socket. 
sockobj = socket(AF_INET, SOCK_STREAM)
 
# Vincula o servidor ao número de porto
sockobj.bind((meuHost, minhaPort))
 

sockobj.listen(2)
 
 
while True:
    # Aceita uma conexão quando encontrada e devolve a
    # um novo socket conexão e o endereço do cliente
    # conectado
    conexão, endereço = sockobj.accept()
    print('Server conectado por', endereço)
     
    while True:
        # Recebe dados enviado pelo cliente
        data = conexão.recv(1024)
        if not data: break
 
        # O servidor manda de volta uma resposta
        conexão.send(b'Eco=>' + data.upper())
    
    conexão.close()